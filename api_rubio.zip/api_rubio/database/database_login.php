<?php
# Informacion de la base de datos
define("HOSTNAME", "c4ytrsshj.gclientes.com");
define("DATABASE", "c4ytrssh_Bolsa_Salesianos");
define("USERNAME", "c4ytrssh_Bolsa_S");
define("PASSWORD", "84YZwP:Y8}/WU:fjDN82");
