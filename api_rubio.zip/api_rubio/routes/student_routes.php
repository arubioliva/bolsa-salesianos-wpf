<?php
require_once 'controllers/student_controller.php';

function studentExecRoute()
{
	$controller = new StudentController();
	if (isset($_GET['option'])) {
		if ($_SERVER['REQUEST_METHOD'] == 'POST') {
		    if($_GET['option'] == 'studies') {
		        $data = $controller->getStudentsByStudy(POST);
                print json_encode($data, JSON_NUMERIC_CHECK);
		    }else if($_GET['option'] == 'studies_vacants') {
		        $data = $controller->getStudentsByStudyAndVacant(POST);
                print json_encode($data, JSON_NUMERIC_CHECK);
		    }
		} else if ($_SERVER['REQUEST_METHOD'] == 'PUT') {
		}
	} else {
		require_once 'routes.php';
		execRoute($controller);
	}
}
