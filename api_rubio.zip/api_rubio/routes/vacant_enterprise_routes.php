<?php
require_once 'controllers/vacant_enterprise_controller.php';

function vacantEnterpriseExecRoute()
{
	$controller = new VacantEnterpriseController();
	if (isset($_GET['option']) && $_GET['option'] = 'object') {
		if ($_SERVER['REQUEST_METHOD'] == 'POST') {
		} else if ($_SERVER['REQUEST_METHOD'] == 'PUT') {
		}
	} else {
		require_once 'routes.php';
		execRoute($controller);
	}
}
