<?php
require_once 'controllers/idiom_student_controller.php';

function idiomStudentExecRoute()
{
	$controller = new IdiomStudentController();
	if (isset($_GET['option']) ) {
	    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	        if($_GET['option'] = 'idioms_by_student') {
	            $data = $controller->getIdioms(POST);
                print json_encode($data);   
	        }
	    }
	    
		
	} else {
		require_once 'routes.php';
		execRoute($controller);
	}
}
