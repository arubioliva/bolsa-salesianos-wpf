<?php
require_once 'controllers/level_study_controller.php';

function levelStudyExecRoute()
{
	$controller = new LevelStudyController();
	if (isset($_GET['option']) && $_GET['option'] = 'object') {
		if ($_SERVER['REQUEST_METHOD'] == 'POST') {
		} else if ($_SERVER['REQUEST_METHOD'] == 'PUT') {
		}
	} else {
		require_once 'routes.php';
		execRoute($controller);
	}
}
