<?php
require_once 'controllers/vacant_controller.php';

function vacantExecRoute()
{
	$controller = new VacantController();
	if (isset($_GET['option']) ) {
	    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	        if($_GET['option'] = 'vacants_for_student') {
	            $data = $controller->getVacants(POST);
                print json_encode($data, JSON_NUMERIC_CHECK);   
	        }
	    }
	} else {
		require_once 'routes.php';
		execRoute($controller);
	}
}
