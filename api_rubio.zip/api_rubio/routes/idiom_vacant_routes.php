<?php
require_once 'controllers/idiom_vacant_controller.php';

function idiomVacantExecRoute()
{
	$controller = new IdiomVacantController();
	if (isset($_GET['option']) && $_GET['option'] = 'object') {
		if ($_SERVER['REQUEST_METHOD'] == 'POST') {
		} else if ($_SERVER['REQUEST_METHOD'] == 'PUT') {
		}
	} else {
		require_once 'routes.php';
		execRoute($controller);
	}
}
