<?php
# path
require_once './routes/college_routes.php';
require_once './routes/credential_routes.php';
require_once './routes/employment_contract_routes.php';
require_once './routes/enterprise_routes.php';
require_once './routes/idiom_routes.php';
require_once './routes/idiom_student_routes.php';
require_once './routes/idiom_vacant_routes.php';
require_once './routes/language_routes.php';
require_once './routes/level_language_routes.php';
require_once './routes/level_study_routes.php';
require_once './routes/selection_routes.php';
require_once './routes/student_routes.php';
require_once './routes/study_routes.php';
require_once './routes/study_student_routes.php';
require_once './routes/type_credential_routes.php';
require_once './routes/vacant_routes.php';
require_once './routes/vacant_enterprise_routes.php';
require_once './routes/work_experience_routes.php';


if (isset($_GET['url'])) {
    $args = explode('/', $_GET['url']);
	define("POST", json_decode(file_get_contents('php://input'), true));
    switch ($args[0]) {
            # method
		case 'colleges':
			collegeExecRoute();
			break;
		case 'credentials':
			credentialExecRoute();
			break;
		case 'employments_contract':
			employmentContractExecRoute();
			break;
		case 'enterprises':
			enterpriseExecRoute();
			break;
		case 'idioms':
			idiomExecRoute();
			break;
		case 'idioms_student':
			idiomStudentExecRoute();
			break;
		case 'idioms_vacant':
			idiomVacantExecRoute();
			break;
		case 'languages':
			languageExecRoute();
			break;
		case 'levels_language':
			levelLanguageExecRoute();
			break;
		case 'levels_study':
			levelStudyExecRoute();
			break;
		case 'selections':
			selectionExecRoute();
			break;
		case 'students':
			studentExecRoute();
			break;
		case 'studies':
			studyExecRoute();
			break;
		case 'studies_student':
			studyStudentExecRoute();
			break;
		case 'types_credential':
			typeCredentialExecRoute();
			break;
		case 'vacants':
			vacantExecRoute();
			break;
		case 'vacants_enterprise':
			vacantEnterpriseExecRoute();
			break;
		case 'works_experience':
			workExperienceExecRoute();
			break;

    }
}
