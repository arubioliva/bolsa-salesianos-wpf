<?php
require_once 'controllers/main_controller.php';

class IdiomStudentController extends MainController
{
	public function __construct()
	{
		$this->setTable("idioms_student");
		# id tabla
		$this->setIdName("id");
	}
	
	public function getIdioms($data)
    {
        $clause = "SELECT * FROM idioms, idioms_student WHERE idioms.id = idioms_student.idiom AND idioms_student.student = ?";
        try {
            $command = $this->getDatabase()->getInstance()->getConnection()->prepare($clause);
            $command->execute(array_values($data));
            $preview = $command->fetchAll(PDO::FETCH_ASSOC);
            return $preview ? $preview : NULL;
        } catch (PDOException $e) {
            return array("status" => -1, "error" => $e);

        }
    }
}
