<?php
require_once 'controllers/main_controller.php';

class StudentController extends MainController
{
	public function __construct()
	{
		$this->setTable("students");
		# id tabla
		$this->setIdName("dni");
	}
	
	public function getStudentsByStudy($data)
    {
        try {
            $clause =isset($data) && count(array_keys($data)) > 0 ? "and ss." . implode(" = ? AND ss.", array_keys($data)) . " = ?" : "";
            $command = $this->getDatabase()->getInstance()->getConnection()->prepare("SELECT st.* FROM students st, studies_student ss WHERE ss.student = st.dni " . $clause);
            $command->execute(array_values($data));
            return $command->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            return array("status" => -1, "error" => $e);
        }
    }
    
   public function getStudentsByStudyAndVacant($data)
    {
      try {
        $clause_vacant = count($data["selection"]) > 0 ? " AND se." . implode(" = ? AND se.", array_keys($data["selection"])) . " = ?" : "";
        $clause_study_student =  count($data["study_student"]) > 0 ? " AND ss." . implode(" = ? AND ss.", array_keys($data["study_student"])) . " = ?" : "";
        $clause_idiom =  count($data["idiom"]) > 0 ? " AND im." . implode(" = ? AND im.", array_keys($data["idiom"])) . " = ?" : "";
        $from = (count($data["study_student"]) > 0 ? ", studies_student ss" : "") . (count($data["selection"]) > 0 ? ", selections se" : "") . (count($data["idiom"]) > 0 ? ", idioms im, idioms_vacant iv" : "");
        $where = array();
        
        if(count($data["study_student"]) > 0 )
        {
          $where[] = "ss.student = st.dni";
        }
        if( count($data["selection"]) > 0 )
        {
          $where[] = "se.student = st.dni";
        }
        if(count($data["idiom"]) > 0 )
        {
          $where[] = "se.student = st.dni";
        }
        if(count($data["idiom"]) > 0  &&  count($data["selection"]) > 0 ){
          $where[] = "iv.vacant = se.vacant AND iv.idiom = im.id";
        }
    
        $command = $this->getDatabase()->getInstance()->getConnection()->prepare("SELECT st.* FROM students st" . $from . (count($where) > 0 ? " WHERE " . implode(" AND ", $where) . $clause_vacant . $clause_study_student . $clause_idiom: "") . " GROUP BY st.dni");
        $command->execute(array_merge(array_values($data["selection"]), array_values($data["study_student"]), array_values($data["idiom"])));
        return $command->fetchAll(PDO::FETCH_ASSOC);
      } catch (PDOException $e) {
        return array("status" => -1, "error" => $e);
      }
    }
    
}
