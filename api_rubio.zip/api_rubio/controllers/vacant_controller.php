<?php
require_once 'controllers/main_controller.php';

class VacantController extends MainController
{
	public function __construct()
	{
		$this->setTable("vacants");
		# id tabla
		$this->setIdName("id");
	}
	
	public function getVacants($data)
    {
        $clause = "SELECT vc.* FROM vacants vc, studies_student ss WHERE ss.study = vc.study AND ss.student = ? GROUP BY vc.id";
        try {
            $command = $this->getDatabase()->getInstance()->getConnection()->prepare($clause);
            $command->execute(array_values($data));
            $preview = $command->fetchAll(PDO::FETCH_ASSOC);
            return $preview ? $preview : NULL;
        } catch (PDOException $e) {
            return array("status" => -1, "error" => $e);

        }
    }
}
